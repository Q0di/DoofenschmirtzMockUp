var app = angular.module("computer", ['ngRoute'])
  /* dependency injection*/
  .config(['$routeProvider', function($routeProvider) {
    $routeProvider.
    when('/main', {
      /*view*/
      templateUrl: 'main.html',
      controller: 'MainCtrl'
    }).
    when('/about', {
      /*view*/
      templateUrl: 'about.html',
      controller: 'MainCtrl'
    }).
    when('/inventions', {
      /*view*/
      templateUrl: 'inventions.html',
      controller: 'InventionsCtrl'
    }).
    when('/careers', {
      /*view*/
      templateUrl: 'careers.html',
      controller: 'CareersCtrl'
    }).
    otherwise({
      redirectTo: '/main'
    })

  }])

.controller('MainCtrl', ['$scope', '$http', function($scope, $http) {
    /* How to make a get request */
    $http.get('services.json').then(function(response) {
      $scope.services = response.data;
    });


  }])
  .controller('InventionsCtrl', ['$scope', '$http', function($scope, $http) {
    /* How to make a get request */
    $http.get('inventions.json').then(function(response) {
      $scope.inventions = response.data;
    });
  }])
  .controller('CareersCtrl', ['$scope', '$http', function($scope, $http) {

    /* How to make a get request */
    $http.get('positions.json').then(function(response) {
      $scope.positions = response.data;
    });
  }]);